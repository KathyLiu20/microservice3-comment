create
    definer = rdsadmin@localhost procedure rds_kill_query(IN thread bigint) deterministic reads sql data
BEGIN
   DECLARE l_user varchar(16);
   DECLARE l_host varchar(64);

   SELECT user, host INTO l_user, l_host
   FROM information_schema.processlist
   WHERE id = thread;

   IF l_user = "rdsadmin" AND l_host LIKE "localhost%" THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT KILL RDSADMIN QUERY';
   ELSEIF l_user = "rdsrepladmin" THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT KILL RDSREPLADMIN QUERY';
   ELSE
      KILL QUERY thread;
   END IF;
END;

