create
    definer = rdsadmin@localhost procedure rds_set_source_delay(IN delay int)
BEGIN
DECLARE v_mysql_version VARCHAR(20);
DECLARE v_called_by_user VARCHAR(50);
DECLARE sql_logging BOOLEAN;
SELECT user() into v_called_by_user;
SELECT version() into v_mysql_version;

IF delay NOT BETWEEN 0 AND 86400 THEN
   SELECT  'For source delay the value must be between 0 and 86400 inclusive' AS Message;
ELSE
   SELECT @@sql_log_bin into sql_logging;
   SET @@sql_log_bin=off;
   SET @cmd = CONCAT('CHANGE REPLICATION SOURCE TO SOURCE_DELAY = ', delay);
   PREPARE rds_set_delay FROM @cmd;
   EXECUTE rds_set_delay;
   DEALLOCATE PREPARE rds_set_delay;
   UPDATE mysql.rds_configuration SET value = delay WHERE name = 'source delay';
   COMMIT;
   INSERT INTO mysql.rds_history(called_by_user, action, mysql_version, master_delay)
   VALUES(v_called_by_user, 'set source delay', v_mysql_version, delay);
   COMMIT;
   SELECT 'source delay is set successfully.' AS Message;
   SET @@sql_log_bin = sql_logging;
END IF;
END;

